import os
from io import StringIO 
from apscheduler.schedulers.blocking import BlockingScheduler

#Read the Kaggle and AWS keys from keys.txt file
keys_file = open('keys.txt', 'r')
Lines = keys_file.readlines()

keys = []
for line in Lines:
  line = line.strip()
  keys.append(line)
  
KAGGLE_USERNAME = keys[0]
KAGGLE_KEY = keys[1]

AWS_ACCESS_KEY_ID = keys[2]
AWS_SECRET_ACCESS_KEY = keys[3]

#Load keys to env varaibles
os.environ['KAGGLE_USERNAME'] = KAGGLE_USERNAME
os.environ['KAGGLE_KEY'] = KAGGLE_KEY
os.environ['AWS_ACCESS_KEY_ID'] = AWS_ACCESS_KEY_ID
os.environ['AWS_SECRET_ACCESS_KEY'] = AWS_SECRET_ACCESS_KEY

print(os.environ['KAGGLE_USERNAME'])
print(os.environ['KAGGLE_KEY'])
print(os.environ['AWS_ACCESS_KEY_ID'])
print(os.environ['AWS_SECRET_ACCESS_KEY'])

def exeucte_pipeline():

	#Read the dataset from Kaggle
	from kaggle.api.kaggle_api_extended import KaggleApi

	dataset = 'abhinav89/telecom-customer'
	path = 'datasets/telecom-customer'

	api = KaggleApi()
	api.authenticate()
	api.dataset_download_files(dataset, 'Telecom_customer churn.csv', path, unzip=True)

	#Load date into Pandas dataframe and explore it 
	import pandas as pd
	df_copy = pd.read_csv('Telecom_customer churn.csv/Telecom_customer churn.csv')
	print(len(df_copy)) 
	
	df = df_copy.copy()

	print("row x columns of data   ", df.shape) # row x columns of data
	print("size of data   ", df.size) # size of data

	print("##################################################################")
	df.info()
	print("##################################################################")

	# Do some data preparation
	#Find out missing values
	miss = df.isnull().sum().sort_values(ascending = False).head(44)
	#Drop missing values
	df.dropna(inplace=True)
	print("Number of missing values : AFTER  ", sum(df.isnull().sum()>0))

	#Move the prepared dataset to a new file 
	df.to_csv('prepared_file.csv', header=False)
	with open("prepared_file.csv", mode='w', newline='\n') as f:
	    df.to_csv(f, sep=",",index=False, line_terminator='\n',encoding='utf-8')
    
	print("Prepared file exported!")

	#Connect to the PostgreSQL database
	import psycopg2
	import csv

	conn = psycopg2.connect(database="test-db",
			user='postgres', password='password',
			host='127.0.0.1', port='5432'
	)

	conn.autocommit = True
	cursor = conn.cursor()

	#Create a table "test" using some of the columns from dataset
	sql1 = '''CREATE TABLE test(rev_Mean float, mou_Mean float, totmrc_Mean float, da_Mean float, ovrmou_Mean float, ovrrev_Mean float, vceovr_Mean float, datovr_Mean float,	roam_Mean float,change_mou float,change_rev float,	drop_vce_Mean float, drop_dat_Mean float, blck_vce_Mean float, blck_dat_Mean float, unan_vce_Mean float, unan_dat_Mean float, plcd_vce_Mean float, plcd_dat_Mean float, recv_vce_Mean float, recv_sms_Mean float, comp_vce_Mean float, comp_dat_Mean float, custcare_Mean float, ccrndmou_Mean float,		cc_mou_Mean float, inonemin_Mean float,	threeway_Mean float, mou_cvce_Mean float,mou_cdat_Mean float, mou_rvce_Mean float,owylis_vce_Mean	float,	mouowylisv_Mean	float, iwylis_vce_Mean	float,	mouiwylisv_Mean	float,	peak_vce_Mean	float,	peak_dat_Mean	float,	mou_peav_Mean	float, mou_pead_Mean	float,	opk_vce_Mean	float,	opk_dat_Mean	float,	mou_opkv_Mean	float,	mou_opkd_Mean	float,	drop_blk_Mean	float, attempt_Mean	float,	complete_Mean	float,	callfwdv_Mean	float,	callwait_Mean	float,	churn	int,	months	int, uniqsubs int, actvsubs int,	new_cell varchar(30),	crclscod varchar(30),	asl_flag varchar(30),	totcalls int,	totmou	float,totrev	float,adjrev	float, adjmou	float, adjqty	float, avgrev	float,avgmou	float,avgqty	float,avg3mou	float,avg3qty	float,avg3rev	float,avg6mou	float,avg6qty	float,avg6rev	float, prizm_social_one varchar(30),	area	varchar(50),dualband	varchar(30),refurb_new varchar(30),	hnd_price	float,
	phones float,		models	float,	hnd_webcap varchar(30),	truck	float,	rv	 float,	ownrent	varchar(30),	lor	float,	dwlltype varchar(30), marital	varchar(30), adults	float,	infobase varchar(30),	income	float,	numbcars float,		HHstatin varchar(30),	dwllsize varchar(30),	 
	forgntvl float,		 ethnic	varchar(30), kid0_2	varchar(30), kid3_5	varchar(30), kid6_10	varchar(30), kid11_15 varchar(30),
	kid16_17 varchar(30),	creditcd varchar(30),	eqpdays	float,Customer_ID int);'''

	cursor.execute(sql1)
	print("New Table created")

	#Write the data from prepared file to test table
	with open('prepared_file.csv', 'r') as f:
	    next(f) # Skip the header row.
	    cursor.copy_from(f, 'test', sep=',')
    
	print("Records inserted") 


	#Read the data back from the table
	indx = 0 
	sql2 = '''select * from test;'''
	cursor.execute(sql2)
	for i in cursor.fetchall():
		#print(i)
		indx = indx + 1 

	print("Records retrieved:   ", indx)
	
	#Drop the table 
	sql = '''DROP TABLE test;'''
	cursor.execute(sql)
	print("Existing Table dropped")

	conn.commit()
	conn.close()

	#Load prepared data into a data lake i.e. AWS S3 bucket
	import boto3
	
	#Creating Session With Boto3.
	session = boto3.Session(
	aws_access_key_id=AWS_ACCESS_KEY_ID,
	aws_secret_access_key=AWS_SECRET_ACCESS_KEY
	)

	#Creating S3 Resource From the Session.
	s3_res = session.resource('s3')
	bucket_name = 'stack-pravin'
	s3_object_name = 'prepared_file.csv'

	csv_buffer = StringIO()
	df.to_csv(csv_buffer)

	s3_res.Object(bucket_name, s3_object_name).put(Body=csv_buffer.getvalue())

	print("Dataframe is saved as CSV in S3 bucket.")

scheduler = BlockingScheduler()
scheduler.add_job(exeucte_pipeline, 'interval', minutes=2)
scheduler.start()