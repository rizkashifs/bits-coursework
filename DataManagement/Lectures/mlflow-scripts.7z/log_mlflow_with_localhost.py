import mlflow

mlflow.set_tracking_uri("http://localhost:5000")
mlflow.set_experiment("check-localhost-connection")

# Define the model hyperparameters
params = {
    "solver": "lbfgs",
    "max_iter": 1000,
    "multi_class": "auto",
    "random_state": 8888,
}
accuracy = 0.79

from matplotlib import pyplot as plt

# Generate a plot
plt.plot([1, 2, 3], [4, 5, 6])

with mlflow.start_run():
    mlflow.log_metric("foo", 1)
    mlflow.log_metric("bar", 2)
    
    # Log the loss metric
    mlflow.log_metric("accuracy", accuracy)     

    # Log the hyperparameters
    mlflow.log_params(params)
           
    # Log the plot directly
    mlflow.log_figure(plt.gcf(), 'my_plot.png')
    
    # Assuming 'local_image.png' is a file in the current directory
    mlflow.log_artifact('local_image.png', 'images')    