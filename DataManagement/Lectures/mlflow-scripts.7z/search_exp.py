from mlflow import MlflowClient
from pprint import pprint
from sklearn.ensemble import RandomForestRegressor


client = MlflowClient(tracking_uri="http://127.0.0.1:5000")

all_experiments = client.search_experiments()

print("***************************************************")
print(all_experiments)
print("***************************************************")

search_experiment = [
    {"name": experiment.name, "lifecycle_stage": experiment.lifecycle_stage}
    for experiment in all_experiments
    if experiment.name == "Apple_Models"
][0]


print("***************************************************")
print(search_experiment)
print("***************************************************")


# Use search_experiments() to search on the project_name tag key

apples_experiment = client.search_experiments(
    filter_string="tags.`project_name` = 'grocery-forecasting'"
)

print(vars(apples_experiment[0]))
